package com.bactro.modplus.mixin;

import com.bactro.modplus.BactroModPlus;
import net.minecraft.client.render.LightmapTextureManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Помечает момент расчёта карты освещения (для Fullbright, см. SimpleOptionMixin). */
@Mixin(LightmapTextureManager.class)
public class LightmapTextureManagerMixin {
    @Inject(method = "update", at = @At("HEAD"))
    private void bactro$lightmapStart(float delta, CallbackInfo ci) {
        BactroModPlus.inLightmapUpdate = true;
    }

    @Inject(method = "update", at = @At("RETURN"))
    private void bactro$lightmapEnd(float delta, CallbackInfo ci) {
        BactroModPlus.inLightmapUpdate = false;
    }
}
