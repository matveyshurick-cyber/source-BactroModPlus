package com.bactro.modplus.mixin;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Для эффекта Darkness рендер получает коэффициент 0 (пульсация яркости и туман отключены).
 * Сам эффект на игроке остаётся: иконка и таймер в HUD на месте.
 */
@Mixin(StatusEffectInstance.class)
public abstract class StatusEffectInstanceMixin {
    @Inject(method = "getFadeFactor", at = @At("HEAD"), cancellable = true)
    private void bactro$noDarknessFactor(LivingEntity entity, float tickProgress, CallbackInfoReturnable<Float> cir) {
        StatusEffectInstance self = (StatusEffectInstance) (Object) this;
        if (self.getEffectType().equals(StatusEffects.DARKNESS)) {
            cir.setReturnValue(0.0F);
        }
    }
}
