package com.bactro.modplus.mixin;

import com.bactro.modplus.BactroModPlus;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Помечает момент отрисовки сердечек (для LivingEntityMixin). */
@Mixin(InGameHud.class)
public class InGameHudMixin {
    @Inject(method = "renderHealthBar", at = @At("HEAD"))
    private void bactro$healthStart(DrawContext context, PlayerEntity player, int x, int y, int lines,
                                    int regeneratingHeartIndex, float maxHealth, int lastHealth, int health,
                                    int absorption, boolean blinking, CallbackInfo ci) {
        BactroModPlus.inHealthBar = true;
    }

    @Inject(method = "renderHealthBar", at = @At("RETURN"))
    private void bactro$healthEnd(DrawContext context, PlayerEntity player, int x, int y, int lines,
                                  int regeneratingHeartIndex, float maxHealth, int lastHealth, int health,
                                  int absorption, boolean blinking, CallbackInfo ci) {
        BactroModPlus.inHealthBar = false;
    }
}
