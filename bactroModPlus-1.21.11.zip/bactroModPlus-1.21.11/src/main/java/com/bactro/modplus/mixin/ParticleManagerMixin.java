package com.bactro.modplus.mixin;

import net.minecraft.client.particle.ParticleManager;
import net.minecraft.entity.Entity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Убирает частицы при срабатывании тотема. */
@Mixin(ParticleManager.class)
public class ParticleManagerMixin {
    @Inject(
        method = "addEmitter(Lnet/minecraft/entity/Entity;Lnet/minecraft/particle/ParticleEffect;I)V",
        at = @At("HEAD"),
        cancellable = true
    )
    private void bactro$noTotemParticles(Entity entity, ParticleEffect parameters, int maxAge, CallbackInfo ci) {
        if (parameters.getType() == ParticleTypes.TOTEM_OF_UNDYING) {
            ci.cancel();
        }
    }
}
