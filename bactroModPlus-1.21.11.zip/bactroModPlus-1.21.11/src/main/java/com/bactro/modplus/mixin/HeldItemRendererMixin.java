package com.bactro.modplus.mixin;

import com.bactro.modplus.BactroModPlus;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Уменьшает щит в руке от первого лица. */
@Mixin(HeldItemRenderer.class)
public class HeldItemRendererMixin {
    private static final String RENDER_ITEM =
        "renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemDisplayContext;"
        + "Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;I)V";

    @Inject(method = RENDER_ITEM, at = @At("HEAD"))
    private void bactro$shieldScaleStart(LivingEntity entity, ItemStack stack, ItemDisplayContext context,
                                         MatrixStack matrices, OrderedRenderCommandQueue queue, int light, CallbackInfo ci) {
        if (stack.isOf(Items.SHIELD) && context.isFirstPerson()) {
            matrices.push();
            float s = BactroModPlus.SHIELD_SCALE;
            matrices.scale(s, s, s);
        }
    }

    @Inject(method = RENDER_ITEM, at = @At("RETURN"))
    private void bactro$shieldScaleEnd(LivingEntity entity, ItemStack stack, ItemDisplayContext context,
                                       MatrixStack matrices, OrderedRenderCommandQueue queue, int light, CallbackInfo ci) {
        if (stack.isOf(Items.SHIELD) && context.isFirstPerson()) {
            matrices.pop();
        }
    }
}
