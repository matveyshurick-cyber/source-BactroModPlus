package com.bactro.modplus.mixin;

import com.bactro.modplus.BactroModPlus;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.entry.RegistryEntry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Пока рисуются сердечки, эффект иссушения "не виден", поэтому они остаются обычными (не чёрными).
 * Работает только внутри InGameHud.renderHealthBar, на геймплей не влияет.
 */
@Mixin(LivingEntity.class)
public class LivingEntityMixin {
    @Inject(method = "hasStatusEffect", at = @At("HEAD"), cancellable = true)
    private void bactro$hideWitherInHearts(RegistryEntry<StatusEffect> effect, CallbackInfoReturnable<Boolean> cir) {
        if (BactroModPlus.inHealthBar && effect.equals(StatusEffects.WITHER)) {
            cir.setReturnValue(false);
        }
    }
}
