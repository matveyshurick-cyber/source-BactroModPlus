package com.bactro.modplus.mixin;

import com.bactro.modplus.BactroModPlus;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.SimpleOption;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Fullbright: пока считается карта освещения, гамма читается как большое значение.
 * В настройках и в options.txt значение не меняется.
 */
@Mixin(SimpleOption.class)
public class SimpleOptionMixin {
    @Inject(method = "getValue", at = @At("HEAD"), cancellable = true)
    private void bactro$fullbright(CallbackInfoReturnable<Object> cir) {
        if (BactroModPlus.fullbright && BactroModPlus.inLightmapUpdate) {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client != null && (Object) this == client.options.getGamma()) {
                cir.setReturnValue(BactroModPlus.FULLBRIGHT_GAMMA);
            }
        }
    }
}
