package com.bactro.modplus;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class BactroModPlus implements ClientModInitializer {
    public static final String MOD_ID = "bactromodplus";

    /** Во сколько раз уменьшать щит в руке (1.0 = без изменений). */
    public static final float SHIELD_SCALE = 0.6f;

    /** Fullbright включён (переключается клавишей B). */
    public static boolean fullbright = true;

    /** Значение гаммы при включённом Fullbright. */
    public static final double FULLBRIGHT_GAMMA = 16.0;

    /** true только пока идёт расчёт карты освещения (LightmapTextureManager.update). */
    public static boolean inLightmapUpdate = false;

    /** true только пока рисуются сердечки здоровья (InGameHud.renderHealthBar). */
    public static boolean inHealthBar = false;

    private static KeyBinding toggleFullbrightKey;

    @Override
    public void onInitializeClient() {
        // Darkness от Вардена: эффект остаётся на игроке, но его "сила" для рендера = 0.
        // См. StatusEffectInstanceMixin.

        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of(MOD_ID, "main"));
        toggleFullbrightKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.bactromodplus.fullbright",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_B,
            category
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleFullbrightKey.wasPressed()) {
                fullbright = !fullbright;
                if (client.player != null) {
                    client.player.sendMessage(
                        Text.literal("Fullbright: " + (fullbright ? "ВКЛ" : "ВЫКЛ")), true);
                }
            }
        });
    }
}
