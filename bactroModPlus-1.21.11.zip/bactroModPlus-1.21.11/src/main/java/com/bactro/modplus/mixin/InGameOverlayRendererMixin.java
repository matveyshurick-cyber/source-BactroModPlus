package com.bactro.modplus.mixin;

import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.random.Random;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Убирает огонь на экране и анимацию тотема (в 1.21.11 летящий предмет рисуется здесь). */
@Mixin(InGameOverlayRenderer.class)
public class InGameOverlayRendererMixin {
    @Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true)
    private static void bactro$noFireOverlay(MatrixStack matrices, VertexConsumerProvider vertexConsumers, Sprite sprite, CallbackInfo ci) {
        ci.cancel();
    }

    @Inject(method = "setFloatingItem", at = @At("HEAD"), cancellable = true)
    private void bactro$noTotemItem(ItemStack stack, Random random, CallbackInfo ci) {
        if (stack.isOf(Items.TOTEM_OF_UNDYING)) {
            ci.cancel();
        }
    }
}
